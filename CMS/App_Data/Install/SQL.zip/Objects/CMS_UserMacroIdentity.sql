SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CMS_UserMacroIdentity](
	[UserMacroIdentityID] [int] IDENTITY(1,1) NOT NULL,
	[UserMacroIdentityLastModified] [datetime2](7) NOT NULL,
	[UserMacroIdentityUserID] [int] NOT NULL,
	[UserMacroIdentityMacroIdentityID] [int] NULL,
	[UserMacroIdentityUserGuid] [uniqueidentifier] NOT NULL,
 CONSTRAINT [PK_CMS_UserMacroIdentity] PRIMARY KEY CLUSTERED 
(
	[UserMacroIdentityID] ASC
)
)
GO
CREATE NONCLUSTERED INDEX [IX_CMS_UserMacroIdentity_UserMacroIdentityMacroIdentityID] ON [dbo].[CMS_UserMacroIdentity]
(
	[UserMacroIdentityMacroIdentityID] ASC
)
GO
CREATE UNIQUE NONCLUSTERED INDEX [UQ_CMS_UserMacroIdentity_UserMacroIdentityUserID] ON [dbo].[CMS_UserMacroIdentity]
(
	[UserMacroIdentityUserID] ASC
)
GO
ALTER TABLE [dbo].[CMS_UserMacroIdentity] ADD  CONSTRAINT [DEFAULT_CMS_UserMacroIdentity_UserMacroIdentityLastModified]  DEFAULT ('1/1/0001 12:00:00 AM') FOR [UserMacroIdentityLastModified]
GO
ALTER TABLE [dbo].[CMS_UserMacroIdentity] ADD  CONSTRAINT [DEFAULT_CMS_UserMacroIdentity_UserMacroIdentityUserID]  DEFAULT ((0)) FOR [UserMacroIdentityUserID]
GO
ALTER TABLE [dbo].[CMS_UserMacroIdentity] ADD  CONSTRAINT [DEFAULT_CMS_UserMacroIdentity_UserMacroIdentityUserGuid]  DEFAULT ('00000000-0000-0000-0000-000000000000') FOR [UserMacroIdentityUserGuid]
GO
ALTER TABLE [dbo].[CMS_UserMacroIdentity]  WITH CHECK ADD  CONSTRAINT [FK_CMS_UserMacroIdentity_UserMacroIdentityMacroIdentityID_CMS_MacroIdentity] FOREIGN KEY([UserMacroIdentityMacroIdentityID])
REFERENCES [dbo].[CMS_MacroIdentity] ([MacroIdentityID])
GO
ALTER TABLE [dbo].[CMS_UserMacroIdentity] CHECK CONSTRAINT [FK_CMS_UserMacroIdentity_UserMacroIdentityMacroIdentityID_CMS_MacroIdentity]
GO
ALTER TABLE [dbo].[CMS_UserMacroIdentity]  WITH CHECK ADD  CONSTRAINT [FK_CMS_UserMacroIdentity_UserMacroIdentityUserID_CMS_User] FOREIGN KEY([UserMacroIdentityUserID])
REFERENCES [dbo].[CMS_User] ([UserID])
GO
ALTER TABLE [dbo].[CMS_UserMacroIdentity] CHECK CONSTRAINT [FK_CMS_UserMacroIdentity_UserMacroIdentityUserID_CMS_User]
GO
