SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[OM_ContactChangeRecalculationQueue](
	[ContactChangeRecalculationQueueID] [int] IDENTITY(1,1) NOT NULL,
	[ContactChangeRecalculationQueueContactID] [int] NOT NULL,
	[ContactChangeRecalculationQueueChangedColumns] [nvarchar](max) NULL,
	[ContactChangeRecalculationQueueContactIsNew] [bit] NOT NULL,
	[ContactChangeRecalculationQueueContactWasMerged] [bit] NOT NULL,
 CONSTRAINT [PK_OM_ContactChangeRecalculationQueue] PRIMARY KEY CLUSTERED 
(
	[ContactChangeRecalculationQueueID] ASC
)
)
GO
ALTER TABLE [dbo].[OM_ContactChangeRecalculationQueue] ADD  CONSTRAINT [DEFAULT_OM_ContactChangeRecalculationQueue_ContactChangeRecalculationQueueContactID]  DEFAULT ((0)) FOR [ContactChangeRecalculationQueueContactID]
GO
ALTER TABLE [dbo].[OM_ContactChangeRecalculationQueue] ADD  CONSTRAINT [DEFAULT_OM_ContactChangeRecalculationQueue_ContactChangeRecalculationQueueContactIsNew]  DEFAULT ((0)) FOR [ContactChangeRecalculationQueueContactIsNew]
GO
ALTER TABLE [dbo].[OM_ContactChangeRecalculationQueue] ADD  CONSTRAINT [DEFAULT_OM_ContactChangeRecalculationQueue_ContactChangeRecalculationQueueContactWasMerged]  DEFAULT ((0)) FOR [ContactChangeRecalculationQueueContactWasMerged]
GO
