SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CMS_Personalization](
	[PersonalizationID] [int] IDENTITY(1,1) NOT NULL,
	[PersonalizationGUID] [uniqueidentifier] NOT NULL,
	[PersonalizationLastModified] [datetime2](7) NOT NULL,
	[PersonalizationUserID] [int] NULL,
	[PersonalizationWebParts] [nvarchar](max) NULL,
	[PersonalizationDashboardName] [nvarchar](200) NULL,
	[PersonalizationSiteID] [int] NULL,
 CONSTRAINT [PK_CMS_Personalization] PRIMARY KEY CLUSTERED 
(
	[PersonalizationID] ASC
)
)
GO
CREATE NONCLUSTERED INDEX [IX_CMS_Personalization_PersonalizationSiteID_SiteID] ON [dbo].[CMS_Personalization]
(
	[PersonalizationSiteID] ASC
)
GO
CREATE NONCLUSTERED INDEX [IX_CMS_Personalization_PersonalizationUserID] ON [dbo].[CMS_Personalization]
(
	[PersonalizationUserID] ASC
)
GO
ALTER TABLE [dbo].[CMS_Personalization] ADD  CONSTRAINT [DEFAULT_CMS_Personalization_PersonalizationGUID]  DEFAULT ('00000000-0000-0000-0000-000000000000') FOR [PersonalizationGUID]
GO
ALTER TABLE [dbo].[CMS_Personalization] ADD  CONSTRAINT [DEFAULT_CMS_Personalization_PersonalizationLastModified]  DEFAULT ('9/2/2008 5:36:59 PM') FOR [PersonalizationLastModified]
GO
ALTER TABLE [dbo].[CMS_Personalization]  WITH CHECK ADD  CONSTRAINT [FK_CMS_Personalization_PersonalizationSiteID_CMS_Site] FOREIGN KEY([PersonalizationSiteID])
REFERENCES [dbo].[CMS_Site] ([SiteID])
GO
ALTER TABLE [dbo].[CMS_Personalization] CHECK CONSTRAINT [FK_CMS_Personalization_PersonalizationSiteID_CMS_Site]
GO
ALTER TABLE [dbo].[CMS_Personalization]  WITH CHECK ADD  CONSTRAINT [FK_CMS_Personalization_PersonalizationUserID_CMS_User] FOREIGN KEY([PersonalizationUserID])
REFERENCES [dbo].[CMS_User] ([UserID])
GO
ALTER TABLE [dbo].[CMS_Personalization] CHECK CONSTRAINT [FK_CMS_Personalization_PersonalizationUserID_CMS_User]
GO
